##Function 1 
import json
import boto3
import base64

s3 = boto3.client('s3')

def lambda_handler(event, context):
    """A function to serialize target data from S3"""

    # Get the S3 address from the Step Function event input
    key = event['s3_key']
    bucket = event['s3_bucket']

    # Download the data from S3 to /tmp/image.png
    download_path = '/tmp/image.png'
    s3.download_file(bucket, key, download_path)

    # Read the data from the file
    with open(download_path, 'rb') as f:
        image_data = base64.b64encode(f.read()).decode('utf-8')

    # Pass the data back to the Step Function
    print('Event:', event.keys())
    return {
        'statusCode': 200,
        'body': {
            'image_data': image_data,
            's3_bucket': bucket,
            's3_key': key,
            'inferences': []
        }
    }


##Function 2
import boto3
import json
import base64

ENDPOINT_NAME = 'image-classification-2023-05-01-23-55-29-146'

def lambda_handler(event, context):
    # Decode the image data
    image = base64.b64decode(event['image_data'])  
    
    # Create a client for the SageMaker runtime
    runtime = boto3.client('sagemaker-runtime')
    
    # Invoke the endpoint
    response = runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType='image/png',
        Body=image
    )
    
    # Decode the response
    inferences = response['Body'].read().decode('utf-8')
    
    # We return the data back to the Step Function
    event['inferences'] = json.loads(inferences)
    
    return {
        'statusCode': 200,
        'body': json.dumps(event)
    }


##Function 3
import json
THRESHOLD = .80


def lambda_handler(event, context):
    
    # Grab the inferences from the event
    inferences = event['inferences']
    
    # Check if any values in our inferences are above THRESHOLD
    meets_threshold = any(inference > THRESHOLD for inference in inferences)

    
    # If our threshold is met, pass our data back out of the
    # Step Function, else, end the Step Function with an error
    try:
        if meets_threshold:
            pass
    except: 
        raise("THRESHOLD_CONFIDENCE_NOT_MET")

    return {
        'statusCode': 200,
        'body': json.dumps(event)
    }